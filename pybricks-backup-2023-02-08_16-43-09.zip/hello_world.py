from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
import umath as math

# Import required MicroPython libraries.
from usys import stdin
from uselect import poll

# Register the standard input so we can read keyboard presses.
keyboard = poll()
keyboard.register(stdin)




def pp_floor(floor:list,x_pos,y_pos):
    output = ""

    for y in range(len(floor[0])):
        temp = ""
        for x in range(len(floor)):
            if(x==x_pos and y==y_pos):
                temp+= "R"
            else:
                if(floor[x][y] == 1):
                    temp += "X"
                else:
                    temp += " "
        output = temp + "\n" + output 
    print(output)

hub = PrimeHub()


##--------------- Drive Functions --------------
wheelbase = 120
width = (113+130)/2

left_motor = Motor(Port.E,Direction.CLOCKWISE)
right_motor = Motor(Port.F,Direction.COUNTERCLOCKWISE)
steering = Motor(Port.C,Direction.COUNTERCLOCKWISE)
motors = DriveBase(left_motor,right_motor,88,width)




def turn_angle(angle,distance):
    if(abs(angle)>22):
        raise ValueError
    steering.run_target(100,-(360/24)+angle*-3)
    rad = wheelbase/math.tan(math.radians(angle))+width/2
    arc = 360*(distance/(2*math.pi*rad))
    motors.curve(rad,arc)

def drive(angle,distance):
    if angle == 0:
        steering.run_target(100,-(360/24))
        motors.settings(200)
        motors.straight(distance)
    else:
        turn_angle(angle,distance)



##----------------------- Scanning Functions ----------
ultrasound_motor = Motor(Port.B)
ultrasound = UltrasonicSensor(Port.A)

scan_start = -120
scan_end = 120

def place_point(angle,distance,floor,x_pos,y_pos):## Convert an angle and distance to xy and place on grid
    x = int(((math.sin(math.radians(angle))*distance)/resolution)+x_pos)
    y = int((math.cos(math.radians(angle))*distance/resolution)+y_pos)
    if(x >= 0 and y >= 0 and x < len(floor) and y < len(floor[0]) and distance != 2000):
        floor[x][y] = 1    
        

world = []
resolution = 50 ## Size of each grid cell in mm

def create_world(x_size,y_size):
    for x in range(x_size):
        temp = []
        for y in range(y_size):
            temp.append(0)
        world.append(temp)


def scan_sweep(floor_map, x = 0,y = 0):
    ##  Create the grid to show the area in front
    gear_ratio = -60/20

    ultrasound_motor.run_target(360,scan_start*gear_ratio)
    ultrasound_motor.run_target(200,scan_end*gear_ratio,wait=False)
    point_cloud = {}
    ultrasound.lights.on(100)
    while(ultrasound_motor.angle() != scan_end*gear_ratio):
        ##point_cloud[ultrasound_motor.angle()] = ultrasound.distance()
        place_point(ultrasound_motor.angle()/gear_ratio,ultrasound.distance(),floor_map,x,y)
    ultrasound.lights.off()
    # for angle in point_cloud.keys():
    #     place_point(angle,point_cloud[angle])
    print("-"*21)
    pp_floor(floor_map,x,y)
    ultrasound_motor.run_target(360,0,wait=True)


## --------- Path Finding ----------






# --------- Main Block -------------------

create_world(100,100)
scan_sweep(world,20,0)
drive(0,300)
scan_sweep(world,20,300/resolution)
drive(0,300)
scan_sweep(world,20,600/resolution)
drive(0,300)
scan_sweep(world,20,900/resolution)
drive(0,300)
scan_sweep(world,20,1200/resolution)
drive(0,300)
scan_sweep(world,20,1500/resolution)
drive(0,300)
scan_sweep(world,20,1800/resolution)
drive(0,-1800)
drive(22,1123.94*2)
# drive(0,-1500)
# while True:

  




wait(3000)
##motors.straight(-1000)



